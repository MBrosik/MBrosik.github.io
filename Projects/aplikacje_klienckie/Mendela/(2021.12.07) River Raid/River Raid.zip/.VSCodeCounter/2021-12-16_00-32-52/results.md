# Summary

Date : 2021-12-16 00:32:52

Directory e:\Z Pulpitu\Dokumenty\SZKOŁA\Aplikacje klienckie\Mendela\2021 - 2022\(2021.11.15) Projekt końcowo roczny\River Raid

Total : 55 files,  15884 codes, 829 comments, 1199 blanks, all 17912 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 3 | 10,688 | 45 | 9 | 10,742 |
| JavaScript | 2 | 2,869 | 512 | 545 | 3,926 |
| TypeScript | 47 | 2,284 | 272 | 632 | 3,188 |
| HTML | 2 | 28 | 0 | 10 | 38 |
| SCSS | 1 | 15 | 0 | 3 | 18 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 55 | 15,884 | 829 | 1,199 | 17,912 |
| dist | 2 | 2,812 | 510 | 548 | 3,870 |
| src | 49 | 2,313 | 272 | 640 | 3,225 |
| src\components | 46 | 2,276 | 270 | 630 | 3,176 |
| src\components\modules | 26 | 1,531 | 163 | 354 | 2,048 |
| src\components\modules\constants | 4 | 323 | 54 | 50 | 427 |
| src\components\modules\constants\Levels | 3 | 319 | 54 | 50 | 423 |
| src\components\modules\mapElements | 17 | 997 | 94 | 269 | 1,360 |
| src\components\modules\mapElements\enemies | 8 | 428 | 44 | 117 | 589 |
| src\components\modules\mapElements\enemies\tank | 2 | 183 | 29 | 47 | 259 |
| src\components\types | 1 | 8 | 0 | 1 | 9 |
| src\components\utils | 18 | 556 | 79 | 205 | 840 |
| src\components\utils\TwoJS | 12 | 493 | 66 | 194 | 753 |
| src\components\utils\TwoJS\raycaster | 5 | 251 | 44 | 118 | 413 |

[details](details.md)