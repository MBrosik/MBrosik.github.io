# Details

Date : 2021-12-16 00:32:52

Directory e:\Z Pulpitu\Dokumenty\SZKOŁA\Aplikacje klienckie\Mendela\2021 - 2022\(2021.11.15) Projekt końcowo roczny\River Raid

Total : 55 files,  15884 codes, 829 comments, 1199 blanks, all 17912 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [dist/index.html](/dist/index.html) | HTML | 14 | 0 | 5 | 19 |
| [dist/main.js](/dist/main.js) | JavaScript | 2,798 | 510 | 543 | 3,851 |
| [package-lock.json](/package-lock.json) | JSON | 10,642 | 0 | 1 | 10,643 |
| [package.json](/package.json) | JSON | 31 | 0 | 1 | 32 |
| [src/components/Main.ts](/src/components/Main.ts) | TypeScript | 181 | 28 | 70 | 279 |
| [src/components/modules/GameConfig.ts](/src/components/modules/GameConfig.ts) | TypeScript | 3 | 0 | 0 | 3 |
| [src/components/modules/KeyboardManager.ts](/src/components/modules/KeyboardManager.ts) | TypeScript | 34 | 0 | 7 | 41 |
| [src/components/modules/LoadAllAudio.ts](/src/components/modules/LoadAllAudio.ts) | TypeScript | 36 | 0 | 14 | 50 |
| [src/components/modules/constants/Levels/level1.ts](/src/components/modules/constants/Levels/level1.ts) | TypeScript | 145 | 28 | 21 | 194 |
| [src/components/modules/constants/Levels/level2.ts](/src/components/modules/constants/Levels/level2.ts) | TypeScript | 124 | 22 | 19 | 165 |
| [src/components/modules/constants/Levels/levelInt.d.ts](/src/components/modules/constants/Levels/levelInt.d.ts) | TypeScript | 50 | 4 | 10 | 64 |
| [src/components/modules/constants/mapInfo.ts](/src/components/modules/constants/mapInfo.ts) | TypeScript | 4 | 0 | 0 | 4 |
| [src/components/modules/loadAllImages.ts](/src/components/modules/loadAllImages.ts) | TypeScript | 138 | 15 | 13 | 166 |
| [src/components/modules/mapElements/BlackFloor.ts](/src/components/modules/mapElements/BlackFloor.ts) | TypeScript | 27 | 0 | 4 | 31 |
| [src/components/modules/mapElements/Block.ts](/src/components/modules/mapElements/Block.ts) | TypeScript | 25 | 0 | 4 | 29 |
| [src/components/modules/mapElements/Bridge.ts](/src/components/modules/mapElements/Bridge.ts) | TypeScript | 49 | 0 | 12 | 61 |
| [src/components/modules/mapElements/Bullet.ts](/src/components/modules/mapElements/Bullet.ts) | TypeScript | 58 | 0 | 12 | 70 |
| [src/components/modules/mapElements/Enemy.ts](/src/components/modules/mapElements/Enemy.ts) | TypeScript | 38 | 1 | 13 | 52 |
| [src/components/modules/mapElements/Fuel.ts](/src/components/modules/mapElements/Fuel.ts) | TypeScript | 19 | 0 | 2 | 21 |
| [src/components/modules/mapElements/Player.ts](/src/components/modules/mapElements/Player.ts) | TypeScript | 163 | 15 | 47 | 225 |
| [src/components/modules/mapElements/ScoreBoard.ts](/src/components/modules/mapElements/ScoreBoard.ts) | TypeScript | 142 | 34 | 40 | 216 |
| [src/components/modules/mapElements/destroyAnimation.ts](/src/components/modules/mapElements/destroyAnimation.ts) | TypeScript | 48 | 0 | 18 | 66 |
| [src/components/modules/mapElements/enemies/Ballon.ts](/src/components/modules/mapElements/enemies/Ballon.ts) | TypeScript | 26 | 0 | 9 | 35 |
| [src/components/modules/mapElements/enemies/FighterPlane.ts](/src/components/modules/mapElements/enemies/FighterPlane.ts) | TypeScript | 27 | 4 | 7 | 38 |
| [src/components/modules/mapElements/enemies/Helicopter.ts](/src/components/modules/mapElements/enemies/Helicopter.ts) | TypeScript | 73 | 7 | 18 | 98 |
| [src/components/modules/mapElements/enemies/Ship.ts](/src/components/modules/mapElements/enemies/Ship.ts) | TypeScript | 42 | 3 | 15 | 60 |
| [src/components/modules/mapElements/enemies/WTC.ts](/src/components/modules/mapElements/enemies/WTC.ts) | TypeScript | 18 | 0 | 6 | 24 |
| [src/components/modules/mapElements/enemies/fighterHelicopterBullet.ts](/src/components/modules/mapElements/enemies/fighterHelicopterBullet.ts) | TypeScript | 59 | 1 | 15 | 75 |
| [src/components/modules/mapElements/enemies/tank/Tank.ts](/src/components/modules/mapElements/enemies/tank/Tank.ts) | TypeScript | 93 | 19 | 23 | 135 |
| [src/components/modules/mapElements/enemies/tank/TankBullet.ts](/src/components/modules/mapElements/enemies/tank/TankBullet.ts) | TypeScript | 90 | 10 | 24 | 124 |
| [src/components/modules/test.ts](/src/components/modules/test.ts) | TypeScript | 0 | 0 | 1 | 1 |
| [src/components/types/import.d.ts](/src/components/types/import.d.ts) | TypeScript | 8 | 0 | 1 | 9 |
| [src/components/utils/TwoJS/Camera.ts](/src/components/utils/TwoJS/Camera.ts) | TypeScript | 6 | 1 | 1 | 8 |
| [src/components/utils/TwoJS/Image_Mesh.ts](/src/components/utils/TwoJS/Image_Mesh.ts) | TypeScript | 54 | 0 | 16 | 70 |
| [src/components/utils/TwoJS/PolygonMesh.ts](/src/components/utils/TwoJS/PolygonMesh.ts) | TypeScript | 28 | 1 | 6 | 35 |
| [src/components/utils/TwoJS/Renderer.ts](/src/components/utils/TwoJS/Renderer.ts) | TypeScript | 71 | 7 | 27 | 105 |
| [src/components/utils/TwoJS/Scene.ts](/src/components/utils/TwoJS/Scene.ts) | TypeScript | 11 | 1 | 7 | 19 |
| [src/components/utils/TwoJS/Vector2.ts](/src/components/utils/TwoJS/Vector2.ts) | TypeScript | 48 | 3 | 15 | 66 |
| [src/components/utils/TwoJS/interfaces..d.ts](/src/components/utils/TwoJS/interfaces..d.ts) | TypeScript | 24 | 9 | 4 | 37 |
| [src/components/utils/TwoJS/raycaster/RayRaycaster.ts](/src/components/utils/TwoJS/raycaster/RayRaycaster.ts) | TypeScript | 65 | 21 | 43 | 129 |
| [src/components/utils/TwoJS/raycaster/circleSquareReycaster.ts](/src/components/utils/TwoJS/raycaster/circleSquareReycaster.ts) | TypeScript | 44 | 17 | 26 | 87 |
| [src/components/utils/TwoJS/raycaster/colorRaycaster.ts](/src/components/utils/TwoJS/raycaster/colorRaycaster.ts) | TypeScript | 68 | 6 | 30 | 104 |
| [src/components/utils/TwoJS/raycaster/squarePolygonReycaster.ts](/src/components/utils/TwoJS/raycaster/squarePolygonReycaster.ts) | TypeScript | 56 | 0 | 14 | 70 |
| [src/components/utils/TwoJS/raycaster/squareSquareReycaster.ts](/src/components/utils/TwoJS/raycaster/squareSquareReycaster.ts) | TypeScript | 18 | 0 | 5 | 23 |
| [src/components/utils/audioLoader.ts](/src/components/utils/audioLoader.ts) | TypeScript | 9 | 0 | 2 | 11 |
| [src/components/utils/extending.ts](/src/components/utils/extending.ts) | TypeScript | 22 | 2 | 2 | 26 |
| [src/components/utils/imgReverse.ts](/src/components/utils/imgReverse.ts) | TypeScript | 12 | 1 | 5 | 18 |
| [src/components/utils/img_loader.ts](/src/components/utils/img_loader.ts) | TypeScript | 9 | 0 | 2 | 11 |
| [src/components/utils/inRange.ts](/src/components/utils/inRange.ts) | TypeScript | 4 | 6 | 0 | 10 |
| [src/components/utils/useSleep.ts](/src/components/utils/useSleep.ts) | TypeScript | 7 | 4 | 0 | 11 |
| [src/index.html](/src/index.html) | HTML | 14 | 0 | 5 | 19 |
| [src/index.ts](/src/index.ts) | TypeScript | 8 | 2 | 2 | 12 |
| [src/style.scss](/src/style.scss) | SCSS | 15 | 0 | 3 | 18 |
| [tsconfig.json](/tsconfig.json) | JSON | 15 | 45 | 7 | 67 |
| [webpack.config.js](/webpack.config.js) | JavaScript | 71 | 2 | 2 | 75 |

[summary](results.md)