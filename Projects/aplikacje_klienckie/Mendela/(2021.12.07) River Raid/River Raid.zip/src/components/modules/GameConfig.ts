export default {
   moveBool: true,
}