export default {
   width: 1000,
   height:700
}