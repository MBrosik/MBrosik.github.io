import { Keys } from "../../modules/KeyboardManager";
import { renderer_functions } from "./Renderer";

export default class Camera{ 
   // constructor (public x:number=0, public y:number=-6900){
   constructor (public x:number=0, public y:number=0){                 
   }
}