import Camera from "../Camera";
import Image_Mesh from "../Image_Mesh";
import { Mesh } from "../interfaces.";


export default class colorRaycaster {
   html_dom: HTMLCanvasElement;
   ctx: CanvasRenderingContext2D;
   // bPaint: Mesh[];
   constructor(
      public aPaint: (Mesh[] | Mesh)[],
      public bPaint: (Mesh[] | Mesh)[],
      private camera: Camera,
      width: number,
      height: number,
   ) {


      this.html_dom = document.createElement("canvas");
      this.html_dom.width = width;
      this.html_dom.height = height;

      this.ctx = this.html_dom.getContext("2d")!;
   }
   
   getCollision(specificColor: number | null = null) {
      
      // console.time();

      this.ctx.clearRect(0, 0, this.html_dom.width, this.html_dom.height);
      for (const el of this.aPaint.flat()) {
         el.action(this.ctx, this.camera)
      }
      niceFor: for (const el of this.bPaint.flat()) {

         let { width, height, x, y } = el.map_info

         const imgData = this.ctx.getImageData(x - this.camera.x, y - this.camera.y, width!, height!);
         el.action(this.ctx, this.camera)
         const imgDataAfter = this.ctx.getImageData(x - this.camera.x, y - this.camera.y, width!, height!);

         // console.log( imgData.data.length);


         for (let i = 0; i < imgData.data.length; i += 4) {
            let count = imgData.data[i] + imgData.data[i + 1] + imgData.data[i + 2];
            let count1 = imgDataAfter.data[i] + imgDataAfter.data[i + 1] + imgDataAfter.data[i + 2];


            // && count != 255 * 3
            if (count != 0  && count != count1) {
               // console.timeEnd();
               return true;
            }

         }
      }
      // console.timeEnd();

      return false
   }
}

function colorRaycaster1(
   aPaint: Mesh[],
   bPaint: Mesh[],
   camera: Camera,
   width: number,
   height: number,
): boolean {
   let html_dom = document.createElement("canvas");

   html_dom.width = width;
   html_dom.height = height;

   let ctx = html_dom.getContext("2d")!;

   for (const el of aPaint) {
      el.action(ctx, camera)
   }

   niceFor: for (const el of bPaint) {

      let { width, height, x, y } = el.map_info

      const imgData = ctx.getImageData(x - camera.x, y - camera.y, width!, height!);
      el.action(ctx, camera)
      const imgDataAfter = ctx.getImageData(x - camera.x, y - camera.y, width!, height!);


      for (let i = 0; i < imgData.data.length; i += 4) {
         let count = imgData.data[i] + imgData.data[i + 1] + imgData.data[i + 2];
         let count1 = imgDataAfter.data[i] + imgDataAfter.data[i + 1] + imgDataAfter.data[i + 2];

         if (count != 0 && count != count1) {
            return true;
         }

      }

   }

   return false
}