declare module "*.png" {
  const value: any;
  export default value;
}

declare module "*.wav" {
  const value1: any;
  export default value1;
}